
import os

def add(a,b):
	return a+b

__version__ = "1.0.0"