
import os

def add(a,b):
	return a+b

__version__ = "0.1"